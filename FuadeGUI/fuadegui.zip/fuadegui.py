import tkinter as tk
import subprocess
import os
from datetime import datetime
from PIL import Image, ImageTk

class Fuade:
    def __init__(self, root):
        self.root = root
        self.root.title("FuadeGUI")
        self.root.geometry("1017x660")
        self.root.minsize(1017, 660)
        self.root.maxsize(1017, 660)
        self.root.resizable(False, False)

        # Taskbar frame at the top
        self.taskbar = tk.Frame(root, bg="gray", height=30)
        self.taskbar.place(x=0, y=0, relwidth=1, height=30)

        self.launcher_button = tk.Button(self.taskbar, text="Apps", command=self.open_launcher)
        self.launcher_button.pack(side="left", padx=5, pady=2)

        self.clock_label = tk.Label(self.taskbar, text="00:00 January 1, 2000", bg="gray")
        self.clock_label.pack(side="right", padx=10, pady=2)
        self.update_clock()

        # Wallpaper label (below the taskbar)
        self.wallpaper = tk.Label(root)
        self.wallpaper.place(x=0, y=30, width=1017, height=630)

        # Load wallpaper.png from the same folder as this script
        folder = os.path.dirname(__file__)
        img_path = os.path.join(folder, "wallpaper.png")
        self.bg_image = Image.open(img_path)
        self.bg_image = self.bg_image.resize((1017, 630), Image.LANCZOS)
        self.bg_image_tk = ImageTk.PhotoImage(self.bg_image)
        self.wallpaper.config(image=self.bg_image_tk)

    def open_launcher(self):
        # This will launch packages/fuadegui/apps.py in a new process
        launcher_script = os.path.join(os.getcwd(), "packages", "fuadegui", "apps.py")
        subprocess.Popen(['python', launcher_script])

    def update_clock(self):
        try:
            now = datetime.now()
            current_time = now.strftime("%H:%M %B %d, %Y")
        except:
            current_time = "00:00 January 1, 2000"
        self.clock_label.config(text=current_time)
        self.root.after(1000, self.update_clock)

def main(command, current_directory):
    """
    Entry‐point for your custom‐command loader.
    `core.py` expects to call mod.main(...) when you type `fuadegui`
    in the shell.
    """
    root = tk.Tk()
    app = Fuade(root)
    root.mainloop()
    